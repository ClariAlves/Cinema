
package com.mycompany.cinema;

public class Cinema {

    public static void main(String[] args) {
        
    }
}
