/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jdbc.ConnectBD;
import model.Reserva;

/**
 *
 * @author jhenn
 */
public class ReservaDAO {
    private Connection conn;
    
    public ReservaDAO(){
    this.conn = new ConnectBD().getConnection();
    }
    
    public void cadastrar(Reserva reserva){
        try {
            String sql = "insert int reserva (cpfCliente, idSessao, nDoAssento) values (?, ?, ?,)";
            PreparedStatement psm = conn.prepareStatement(sql);
            psm.setString(1, reserva.getCpf());
            psm.setInt(2,reserva.getIdReserva());
            psm.setInt(3, reserva.getnDoAssento());
            
            psm.execute();
            psm.close();
            
            System.out.println("Cadastra de reserva concluido ");
        } catch (Exception e) {
            
            System.out.println("Erro ao realizar cadastro. " + e); 
        }
    
    }
    
    public List<Reserva> listarReserva() throws SQLException{
        Connection conn = null;
        ResultSet result = null;
        PreparedStatement psm = null;
        
        try {
           String sql = "SELECT * FROM `reserva`";
           List<Reserva> reserva = new ArrayList();
           psm = conn.prepareStatement(sql);
           result = psm.executeQuery();
           Reserva r = new Reserva();
           
           while(result.next()){
                r.setIdReserva(result.getInt("id"));
                r.setCpf(result.getNString("cpfCliente"));
                r.setIdReserva(result.getInt("idReserva"));
                r.setnDoAssento(result.getInt("nDoAssento"));
                
                reserva.add(r);
           } 
        } catch (Exception e) {
            e.printStackTrace();
            return null;
            
        } finally{
            try{
            if(result != null){
                result.close();
            }
            if(psm != null){
                psm.close();
            }
            if(conn != null){
                conn.close();
            }
          }catch(Exception e){
              e.printStackTrace();
          }
        }
        return null;  
    }
}
