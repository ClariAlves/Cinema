/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import jdbc.ConnectBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Pessoa;

/**
 *
 * @author jhenn
 */
public class ClienteDAO {
    
    private Connection conn;

    public ClienteDAO() {
        this.conn = new ConnectBD().getConnection(); 
    }
    
    public void cadastrar(Pessoa cliente){
        try {
            String sql = "insert into cliente (cpf, senha, email, nome, idade, celular) values (?,?,?,?,?,?)";
            PreparedStatement psm = conn.prepareStatement(sql);
            
            psm.setString(1, cliente.getCpf());
            psm.setString(2, cliente.getSenha());
            psm.setString(3, cliente.getEmail());
            psm.setString(4, cliente.getNome());
            psm.setInt(5, cliente.getIdade());
            psm.setString(6, cliente.getCelular());
            
            psm.execute();
            psm.close();
            
            System.out.println("Cadastrado! ");
        } catch (SQLException e) {
            System.out.println("Erro ao realizar cadastro. " + e);
        }
    }
    
}
