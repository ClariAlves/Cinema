/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author jhenn
 */
public class AssentosCinema {
    
        private int nDoAssento;
        private boolean status;

    public AssentosCinema(int nDoAssento, boolean status) {
        this.nDoAssento = nDoAssento;
        this.status = status;
    }

    public void mostra(){
        System.out.println("Numero do assento: " + this.getnDoAssento()
        + "\nstatus: " + this.isStatus());
    }

    public AssentosCinema(int nDoAssento){
        this.nDoAssento = nDoAssento;
    }
    
    public int getnDoAssento() {
        return nDoAssento;
    }
    public void setnDoAssento(int nDoAssento) {
        this.nDoAssento = nDoAssento;
    }
    public boolean isStatus() {
        return status;
    }
    public void setStatus(boolean status) {
        this.status = status;
    }
}
