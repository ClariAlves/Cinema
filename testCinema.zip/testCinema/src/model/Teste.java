/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Clarice
 */
public class Teste {
    
    public static void main(String[] args) {
        
        /*Pessoa p1 = new Pessoa("71269852178", "clarice1@",
                "Clarice@gmail.com", "Clarice", 20, "64996756698");*/
        
        /*Pagamento pag = new Pagamento("", "1234567890123487", 778, "Compras",
        2023, "34/08");*/
    }
}
