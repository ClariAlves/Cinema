/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import DAO.PagamentoDAO;
import model.Pagamento;
import view.PagCinema;

/**
 *
 * @author jhenn
 */
public class PagamentoControler {

    public void compra(PagCinema cinePag) {
        Pagamento pag = new Pagamento();
        PagamentoDAO pDAO = new PagamentoDAO();

        pag.setNumCartao(cinePag.NUMCARTAO.getText());
        pag.setCvv(Integer.parseInt(cinePag.CVV.getText()));
        pag.setNomeCart(cinePag.NOMECARTAO.getText());
        pag.setDataExp(Integer.parseInt(cinePag.ANOEXP.getText()));

        pDAO.PagamentoDAO(pag);
    }
}
