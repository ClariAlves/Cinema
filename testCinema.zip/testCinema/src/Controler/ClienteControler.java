/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import DAO.ClienteDAO;
import model.Pessoa;
import view.Cadastro;

/**
 *
 * @author jhenn
 */
public class ClienteControler {
    
    public void cadastrar(Cadastro cad){
        Pessoa p = new Pessoa();
        ClienteDAO cDAO = new ClienteDAO();
        p.setCpf(cad.CPF.getText());
        p.setNome(cad.NOME.getText());
        p.setEmail(cad.EMAIL.getText());
        p.setIdade(Integer.parseInt(cad.IDADE.getText()));
        p.setCelular(cad.TELEFONE.getText());
        p.setSenha(cad.SENHA.getText());
        
        cDAO.cadastrar(p);
        
    }
    
}
